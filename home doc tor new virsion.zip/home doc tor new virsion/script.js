// ==========================================
// HOME DOCTOR - MAIN JAVASCRIPT
// ==========================================

document.addEventListener("DOMContentLoaded", function () {

    // ------------------------------------------
    // PAGE NAVIGATION
    // ------------------------------------------

    const navLinks = document.querySelectorAll("[data-page]");

    navLinks.forEach(function (link) {
        link.addEventListener("click", function (event) {
            event.preventDefault();

            const page = link.getAttribute("data-page");

            if (page) {
                window.location.href = page;
            }
        });
    });


    // ------------------------------------------
    // APPOINTMENT FORM
    // ------------------------------------------

    const appointmentForm = document.getElementById("appointmentForm");

    if (appointmentForm) {

        appointmentForm.addEventListener("submit", function (event) {

            event.preventDefault();

            const doctor = document.getElementById("doctor");
            const date = document.getElementById("date");
            const time = document.getElementById("time");
            const consultation = document.getElementById("consultation");
            const symptoms = document.getElementById("symptoms");

            if (!doctor || !date || !time) {
                console.error("Appointment form fields are missing.");
                return;
            }

            if (
                doctor.value.trim() === "" ||
                date.value.trim() === "" ||
                time.value.trim() === ""
            ) {
                alert("Please fill all required appointment details.");
                return;
            }

            const appointment = {
                doctor: doctor.value,
                date: date.value,
                time: time.value,
                consultation: consultation ? consultation.value : "Online",
                symptoms: symptoms ? symptoms.value : ""
            };

            // Get old appointments
            let appointments = [];

            try {
                appointments =
                    JSON.parse(localStorage.getItem("homeDoctorAppointments")) || [];
            } catch (error) {
                console.error("Could not read appointments:", error);
                appointments = [];
            }

            // Add new appointment
            appointments.push(appointment);

            // Save appointment
            localStorage.setItem(
                "homeDoctorAppointments",
                JSON.stringify(appointments)
            );

            alert("Appointment booked successfully!");

            appointmentForm.reset();

            displayAppointments();
        });
    }


    // ------------------------------------------
    // DISPLAY SAVED APPOINTMENTS
    // ------------------------------------------

    function displayAppointments() {

        const appointmentList =
            document.getElementById("appointmentList");

        if (!appointmentList) {
            return;
        }

        let appointments = [];

        try {
            appointments =
                JSON.parse(localStorage.getItem("homeDoctorAppointments")) || [];
        } catch (error) {
            console.error("Could not load appointments:", error);
            appointments = [];
        }

        appointmentList.innerHTML = "";

        if (appointments.length === 0) {

            appointmentList.innerHTML = `
                <div class="empty-message">
                    <p>No appointments booked yet.</p>
                </div>
            `;

            return;
        }

        appointments.forEach(function (appointment, index) {

            const card = document.createElement("div");

            card.className = "appointment-card";

            card.innerHTML = `
                <h3>Doctor Appointment</h3>

                <p>
                    <strong>Doctor:</strong>
                    ${escapeHTML(appointment.doctor)}
                </p>

                <p>
                    <strong>Date:</strong>
                    ${escapeHTML(appointment.date)}
                </p>

                <p>
                    <strong>Time:</strong>
                    ${escapeHTML(appointment.time)}
                </p>

                <p>
                    <strong>Consultation:</strong>
                    ${escapeHTML(appointment.consultation)}
                </p>

                ${
                    appointment.symptoms
                        ? `<p>
                            <strong>Symptoms:</strong>
                            ${escapeHTML(appointment.symptoms)}
                           </p>`
                        : ""
                }

                <button
                    class="delete-appointment"
                    data-index="${index}">
                    Cancel Appointment
                </button>
            `;

            appointmentList.appendChild(card);
        });

        // Delete appointment buttons
        const deleteButtons =
            document.querySelectorAll(".delete-appointment");

        deleteButtons.forEach(function (button) {

            button.addEventListener("click", function () {

                const index =
                    parseInt(button.getAttribute("data-index"));

                deleteAppointment(index);
            });
        });
    }


    // ------------------------------------------
    // DELETE APPOINTMENT
    // ------------------------------------------

    function deleteAppointment(index) {

        let appointments = [];

        try {
            appointments =
                JSON.parse(localStorage.getItem("homeDoctorAppointments")) || [];
        } catch (error) {
            appointments = [];
        }

        if (index < 0 || index >= appointments.length) {
            return;
        }

        const confirmDelete =
            confirm("Do you want to cancel this appointment?");

        if (!confirmDelete) {
            return;
        }

        appointments.splice(index, 1);

        localStorage.setItem(
            "homeDoctorAppointments",
            JSON.stringify(appointments)
        );

        displayAppointments();
    }


    // ------------------------------------------
    // DOCTOR SEARCH
    // ------------------------------------------

    const doctorSearch =
        document.getElementById("doctorSearch");

    if (doctorSearch) {

        doctorSearch.addEventListener("input", function () {

            const searchText =
                doctorSearch.value.toLowerCase().trim();

            const doctorCards =
                document.querySelectorAll(".doctor-card");

            doctorCards.forEach(function (card) {

                const cardText =
                    card.textContent.toLowerCase();

                if (cardText.includes(searchText)) {
                    card.style.display = "";
                } else {
                    card.style.display = "none";
                }
            });
        });
    }


    // ------------------------------------------
    // MEDICINE SEARCH
    // ------------------------------------------

    const medicineSearch =
        document.getElementById("medicineSearch");

    if (medicineSearch) {

        medicineSearch.addEventListener("input", function () {

            const searchText =
                medicineSearch.value.toLowerCase().trim();

            const medicineCards =
                document.querySelectorAll(".medicine-card");

            medicineCards.forEach(function (card) {

                const cardText =
                    card.textContent.toLowerCase();

                if (cardText.includes(searchText)) {
                    card.style.display = "";
                } else {
                    card.style.display = "none";
                }
            });
        });
    }


    // ------------------------------------------
    // NEARBY HOSPITAL / CLINIC
    // ------------------------------------------

    const nearbyButton =
        document.getElementById("findNearby");

    if (nearbyButton) {

        nearbyButton.addEventListener("click", function () {

            const resultContainer =
                document.getElementById("nearbyResults");

            if (!navigator.geolocation) {

                if (resultContainer) {
                    resultContainer.innerHTML = `
                        <p>
                            Your browser does not support location services.
                        </p>
                    `;
                }

                return;
            }

            if (resultContainer) {
                resultContainer.innerHTML = `
                    <p>Finding nearby hospitals and clinics...</p>
                `;
            }

            navigator.geolocation.getCurrentPosition(

                function (position) {

                    const latitude =
                        position.coords.latitude;

                    const longitude =
                        position.coords.longitude;

                    findNearbyPlaces(
                        latitude,
                        longitude,
                        resultContainer
                    );
                },

                function (error) {

                    console.error(
                        "Location error:",
                        error
                    );

                    if (resultContainer) {

                        resultContainer.innerHTML = `
                            <p>
                                Location permission was not granted.
                                Please allow location access and try again.
                            </p>
                        `;
                    }
                },

                {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 0
                }
            );
        });
    }


    // ------------------------------------------
    // FIND NEARBY PLACES
    // ------------------------------------------

    async function findNearbyPlaces(
        latitude,
        longitude,
        resultContainer
    ) {

        if (!resultContainer) {
            return;
        }

        const radius = 5000;

        const query = `
            [out:json];
            (
                node["amenity"="hospital"]
                    (around:${radius},${latitude},${longitude});

                way["amenity"="hospital"]
                    (around:${radius},${latitude},${longitude});

                node["amenity"="clinic"]
                    (around:${radius},${latitude},${longitude});

                way["amenity"="clinic"]
                    (around:${radius},${latitude},${longitude});
            );
            out center;
        `;

        const url =
            "https://overpass-api.de/api/interpreter?data=" +
            encodeURIComponent(query);

        try {

            const response =
                await fetch(url);

            if (!response.ok) {
                throw new Error(
                    "Unable to connect to map service."
                );
            }

            const data =
                await response.json();

            displayNearbyPlaces(
                data.elements || [],
                resultContainer
            );

        } catch (error) {

            console.error(
                "Nearby search error:",
                error
            );

            resultContainer.innerHTML = `
                <div class="error-message">
                    <p>
                        Unable to find nearby hospitals or clinics.
                    </p>

                    <p>
                        Please check your internet connection
                        and try again.
                    </p>
                </div>
            `;
        }
    }


    // ------------------------------------------
    // DISPLAY NEARBY PLACES
    // ------------------------------------------

    function displayNearbyPlaces(
        places,
        resultContainer
    ) {

        resultContainer.innerHTML = "";

        if (places.length === 0) {

            resultContainer.innerHTML = `
                <div class="empty-message">
                    <p>
                        No hospitals or clinics found nearby.
                    </p>
                </div>
            `;

            return;
        }

        places.forEach(function (place) {

            const tags =
                place.tags || {};

            const name =
                tags.name || "Hospital / Clinic";

            const type =
                tags.amenity === "hospital"
                    ? "Hospital"
                    : "Clinic";

            const address =
                tags["addr:street"] || "Address not available";

            const phone =
                tags.phone || "Phone number not available";

            const latitude =
                place.lat ||
                (place.center ? place.center.lat : null);

            const longitude =
                place.lon ||
                (place.center ? place.center.lon : null);

            const card =
                document.createElement("div");

            card.className =
                "nearby-card";

            card.innerHTML = `
                <h3>${escapeHTML(name)}</h3>

                <p>
                    <strong>Type:</strong>
                    ${type}
                </p>

                <p>
                    <strong>Address:</strong>
                    ${escapeHTML(address)}
                </p>

                <p>
                    <strong>Phone:</strong>
                    ${escapeHTML(phone)}
                </p>

                ${
                    latitude && longitude
                        ? `
                            <a
                                href="https://www.google.com/maps/search/?api=1&query=${latitude},${longitude}"
                                target="_blank"
                                rel="noopener noreferrer"
                                class="map-button">
                                Open in Google Maps
                            </a>
                          `
                        : ""
                }
            `;

            resultContainer.appendChild(card);
        });
    }


    // ------------------------------------------
    // GLOBAL SEARCH
    // ------------------------------------------

    const globalSearch =
        document.getElementById("globalSearch");

    if (globalSearch) {

        globalSearch.addEventListener("input", function () {

            const searchText =
                globalSearch.value.toLowerCase().trim();

            const searchableCards =
                document.querySelectorAll(
                    ".feature-card, .problem-card, .doctor-card, .medicine-card, .nearby-card"
                );

            searchableCards.forEach(function (card) {

                const text =
                    card.textContent.toLowerCase();

                if (text.includes(searchText)) {
                    card.style.display = "";
                } else {
                    card.style.display = "none";
                }
            });
        });
    }


    // ------------------------------------------
    // HTML SECURITY HELPER
    // ------------------------------------------

    function escapeHTML(value) {

        if (value === null || value === undefined) {
            return "";
        }

        return String(value)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }


    // ------------------------------------------
    // LOAD APPOINTMENTS WHEN PAGE OPENS
    // ------------------------------------------

    displayAppointments();

});